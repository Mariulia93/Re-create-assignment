
Paul Grotesk
�

Thank you for downloading this font!

This font is copyright (c) fargus meiser & atill
All rights reserved. Do not distribute without the author's permission.

Use this FREE font for non-commercial use only! 
If you plan to use it for commercial purposes, contact us before doing so.

===== LINK =====
Or buy the professional version at myfonts.
http://www.myfonts.com/fonts/artill-typs/paul-grotesk-soft/
====================

Have fun and enjoy!

�
L. Bischoff - www.artill.de